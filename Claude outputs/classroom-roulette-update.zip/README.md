# Element Roulette 🧪

A chalkboard-style periodic table that picks which student answers the question
(*Ai sẽ trả lời câu hỏi?*). Students get elements in list order, in one of two modes
(a switch on the spin screen):

- **Use the whole table** (default): the table is shared out so every student gets the
  same number of elements — floor(118 ÷ class size). With 30 students that is 3 each:
  #1 owns H (1), Ga (31) and Pm (61), #2 owns He, Ge and Sm, … and elements 91–118 are unused.
- **Off**: one element each — #1 is H, #2 is He — and the rest of the table is unused. Hit **Spin** (or press **Space**),
the table glows through the students, and a card pops up with the student's name and a
fun fact about their element.

## Features

- **Spin screen**: full periodic table coloured by element group, every element lit. The
  glow shuffles across the table, slows down and lands on one element; that student's other
  elements light up too. Every student owns the same number of elements, and the winner is
  drawn per student, so the pick is fair. The colour key sits in the empty gap at the top of
  the table. Space spins and stops early.
- **Mystery card mode** (*Thẻ bí ẩn* — switch *Bảng | Thẻ bí ẩn* at the top): a big blank
  card is on screen from the start. Spin rolls every field like a slot machine, then they lock
  one by one — element type → period → the element (and its group) → the student — so the class
  can guess along; values still rolling only show options that fit the clues already locked.
  The finished card shows the fun fact with *Mark as tested* / *Absent*. The winner is drawn up
  front exactly like table mode, so the reveal never changes anyone's chance.
- **Teacher / student access**: a device that hasn't been unlocked only shows *Bảng tuần hoàn* and
  *Đoán nguyên tố* (what students open from the QR code). Tap **Giáo viên**, enter the teacher
  password once and that device stays unlocked; **Khóa** switches back to student view.
- **QR for students**: on *Bảng tuần hoàn* and *Đoán nguyên tố* (teacher only) — students scan it
  and get the same page on their phones. For a custom element set the link carries the set itself.
- **Element sets** (*Lớp học → Bộ nguyên tố*): click elements on the table (or a whole group from
  the colour key, or "1–20") to build your own lists for *Đoán nguyên tố*.
- **Tabs**: *Trả lời câu hỏi* · *Bảng tuần hoàn* · *Đoán nguyên tố* · *Lớp học*. Each tab has its own
  link (`/#/table`, `/#/guess`, `/#/classes`), so students can be sent straight to one.
- **Smart periodic table** (*Bảng tuần hoàn thông minh*, for students): click any element for
  its name with IPA (phiên âm) and an English pronunciation button — UK or US accent, normal or
  slow (browser voices), an animated Bohr atom with p⁺/n⁰/e⁻ and electrons per shell,
  atomic number, mass, period/group, state at 25 °C, electron configuration, fun fact and key
  equations (with conditions like t°, xt). Search by symbol, English or Vietnamese name or
  number (accents optional); click the colour key to filter by group; ← → moves between elements.
- **Guess the element** (*Đoán nguyên tố*): 9 clues from hard to easy — type, state, period,
  group, electron configuration, mass, fun fact (name hidden), atomic number, first letter.
  10 points minus one per clue; a wrong guess opens the next clue. Guesses accept symbol,
  English/Vietnamese name (with or without accents) or number. Four levels (1–20, 1–36,
  1–86, all). Space = next clue.
- **Winner card**: element tile, student name, a fun fact, all of the student's elements,
  and three actions:
  *Mark as tested*, *Spin again*, *Absent — skip* (skips them for the rest of the session).
- **Tested last time**: students marked as tested sit out until the marks are cleared.
  When everyone has had a turn, the app offers to start a new round.
- **Element tooltips**: hover any element for its name, group, mass, period/group and the
  student who owns it (and whether they were tested or are absent).
- **Smart list import**: press *Import a list*, or just Ctrl+V anywhere on the class page.
  Paste cells from Excel / Google Sheets, a list from Word or Zalo, or drop a .csv / .txt
  file. It detects the header row and which columns hold the name (joins *Họ đệm* + *Tên*),
  skips STT / ID / date / gender columns, fixes ALL-CAPS names, strips numbering and flags
  duplicates — with a live preview before adding.
- **Class manager**: create, rename and delete classes; reorder, edit and remove students;
  tick or untick "tested last time" by hand.
- **Backup**: everything is saved in the browser (localStorage). Export or import a JSON
  file to move the classes to another computer.
- **Vietnamese / English**: switch with the VI | EN toggle on the class page; the choice is remembered.
  Vietnamese shows IUPAC names as in the new textbooks, plus the familiar name where there
  is one (e.g. *Iron (sắt)*), and groups as *Nhóm VIIIB (8)*.
- **Always fits the screen**: the table scales to the window; nothing scrolls the page
  (the student list scrolls inside its own box).
- Screens slide between each other, and switching *Bảng ⇄ Thẻ bí ẩn* animates too: the old
  view shrinks away, the table's elements fly in as a wave from H, or the card flips in
  (View Transitions API, with a fallback).
- Vietnamese by default; credit *Thực hiện bởi thầy Lê Quang Quí* floats in the bottom-right.
- Chalk-styled dropdowns, switches and checkboxes instead of the browser defaults.
- Sound effects with a mute toggle; respects "reduce motion".

## Run it locally

```bash
pnpm install
pnpm dev
```

## Teacher password

Default: **`thayqui2026`** (capitals, spaces and accents don't matter — "Thầy Quí 2026" works too).

Change it for the live site in Vercel → *Project → Settings → Environment Variables*:
add `VITE_TEACHER_PIN` = your password, then redeploy. Locally, put `VITE_TEACHER_PIN=...` in a
`.env.local` file. Only a hash of the password is built into the app, and changing it locks every
device again.

Note: this keeps students out of the teacher screens on their own phones; it is not bank-grade
security (the class lists only ever live in the teacher's own browser anyway).

## Deploy to Vercel

1. Push this folder to GitHub.
2. In Vercel, **Add New → Project** and import the repo.
3. Vercel detects Vite automatically (build: `npm run build`, output: `dist`). Click **Deploy**.

No server or environment variables are needed. The app uses hash URLs (`#/classes`),
so no rewrite rules are needed either.

## Project layout

```
src/
  data/elements.ts          118 elements: symbol, name, mass, group, position, fun fact (EN)
  data/facts.vi.ts          Vietnamese fun facts and traditional names
  data/chem.ts              electron configurations, states, equations, guess matching
  speech.ts                 English pronunciation, UK / US voices (Web Speech API)
  data/pronunciation.ts     IPA (UK + US) for all 118 names
  pin.ts                    teacher password hashing (shared with vite.config.ts)
  i18n.tsx                  VI/EN strings, language toggle
  store.ts                  classes & students, saved to localStorage
  smartImport.ts            turns pasted sheets / lists / CSV into clean names
  sound.ts                  tiny Web Audio tick / lock / win sounds
  util.ts                   random helpers, Space-key handling
  components/
    PeriodicTable.tsx       the table grid
    SpinScreen.tsx          spin animation, Space shortcut, landed banner
    WinnerModal.tsx         the fun-fact popup
    ExploreScreen.tsx       smart periodic table tab
    ElementDetail.tsx       element card: facts, pronunciation, equations
    GuessScreen.tsx         guess-the-element game
    chemText.tsx            formulas with subscripts, configurations, equations
    BohrAtom.tsx            animated Bohr model
    ElementSetsPanel.tsx    teacher's element sets editor
    QrDialog.tsx            QR code for students
    PinDialog.tsx           teacher password prompt
    CardMode.tsx            mystery card: slot-machine reveal, clue by clue
    ClassesScreen.tsx       class & student manager
    ImportDialog.tsx        paste / drop a class list with live preview
    controls.tsx            chalk dropdown and switch
  index.css                 chalkboard theme
```

## Checking the chemistry data

```bash
npx tsx scripts/check-chem.ts
```

Checks that every electron configuration and shell list adds up to Z electrons, that every
equation is balanced, that all 118 elements have IPA, and that typed guesses ("Fe", "sắt", "sat", "iron", "26") resolve correctly.
